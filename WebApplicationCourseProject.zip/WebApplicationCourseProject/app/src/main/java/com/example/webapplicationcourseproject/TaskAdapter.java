package com.example.webapplicationcourseproject;

public class TaskAdapter extends RecyclerView.Adapter<TaskAdapter.TaskViewHolder> {

    private TaskNotificationHelper notificationHelper;

    public TaskAdapter(List<Task> taskList, Context context) {
        this.taskList = taskList;
        this.context = context;
        notificationHelper = new TaskNotificationHelper(context);
    }

    private List<Task> taskList;

    private OnItemClickListener itemClickListener;

    public interface OnItemClickListener {
        void onItemClick(int position);
    }

    // Метод для редактирования задачи
    public void editTask(int position, Task newTask) {
        taskList.set(position, newTask);
        notifyItemChanged(position);
    }

    // Метод для удаления задачи
    public void deleteTask(int position) {
        taskList.remove(position);
        notifyItemRemoved(position);
    }

    @NonNull
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Создание ViewHolder для элемента списка задач
    }


    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        // Привязка данных задачи к элементу списка
        Task task = taskList.get(position);
        holder.textViewTitle.setText(task.getTitle());
        List<Task> subTasks = task.getSubTasks();
        if (subTasks != null && !subTasks.isEmpty()) {
            SubTaskAdapter subTaskAdapter = new SubTaskAdapter(subTasks);
            holder.recyclerViewSubTasks.setAdapter(subTaskAdapter);
        }
        // Установка значений полей задачи в элементы пользовательского интерфейса
        holder.textViewTaskTitle.setText(task.getTitle());
        holder.textViewTaskDeadline.setText(task.getDeadline());
        holder.textViewTaskPriority.setText(String.valueOf(task.getPriority()));

        // Установка слушателей для кнопок редактирования и удаления задачи
        holder.buttonEdit.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // Открывает диалоговое окно редактирования задачи
                openEditDialog(position, task);
            }
        });

        holder.buttonDelete.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                // Удаляет задачу
                deleteTask(position);
            }
        });
        // Установка слушателя кликов на элемент списка
        holder.itemView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if (itemClickListener != null) {
                    itemClickListener.onItemClick(position);
                }
            }

        });

    }
    public void createNotification(int position) {
        Task task = taskList.get(position);
        notificationHelper.createNotification(task);
    }

    public void cancelNotification(int position) {
        Task task = taskList.get(position);
        notificationHelper.cancelNotification(task.getId());
    }
    // Метод для сохранения задач в хранилище
    public void saveTasks() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("TaskPrefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String jsonTasks = gson.toJson(taskList);
        editor.putString("tasks", jsonTasks);
        editor.apply();
    }

    // Метод для загрузки задач из хранилища
    public void loadTasks() {
        SharedPreferences sharedPreferences = context.getSharedPreferences("TaskPrefs", Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String jsonTasks = sharedPreferences.getString("tasks", null);
        Type type = new TypeToken<ArrayList<Task>>() {}.getType();
        taskList = gson.fromJson(jsonTasks, type);
        if (taskList == null) {
            taskList = new ArrayList<>();
        }
        notifyDataSetChanged();
    }

    public int getItemCount() {
        return taskList.size();
    }
}

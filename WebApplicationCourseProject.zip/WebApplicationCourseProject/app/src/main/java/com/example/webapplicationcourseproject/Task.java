public class Task {
    private String title;
    private String deadline;
    private int priority;

    private List<Task> subTasks;

    public Task(String title, String deadline, int priority) {
        this.title = title;
        this.deadline = deadline;
        this.priority = priority;
    }
}

package com.example.webapplicationcourseproject;

public class TaskDataManager {
    private static final String FILE_NAME = "task_data";
    private Context context;

    public TaskDataManager(Context context) {
        this.context = context;
    }

    public void saveTaskList(List<Task> taskList) {
        try {
            FileOutputStream fileOutputStream = context.openFileOutput(FILE_NAME, Context.MODE_PRIVATE);
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(taskList);
            objectOutputStream.close();
            fileOutputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public List<Task> loadTaskList() {
        List<Task> taskList = new ArrayList<>();
        try {
            FileInputStream fileInputStream = context.openFileInput(FILE_NAME);
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            taskList = (List<Task>) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
        return taskList;
    }
}

package com.example.webapplicationcourseproject;

public class TaskNotificationHelper {
    private Context context;
    private NotificationManager notificationManager;

    public TaskNotificationHelper(Context context) {
        this.context = context;
        notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    public void createNotification(Task task) {
        // Создание уведомления
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "task_channel")
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Напоминание о задаче")
                .setContentText(task.getTitle())
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true);

        // Отправка уведомления
        notificationManager.notify(task.getId(), builder.build());
    }

    public void cancelNotification(int taskId) {
        // Отмена уведомления
        notificationManager.cancel(taskId);
    }
}

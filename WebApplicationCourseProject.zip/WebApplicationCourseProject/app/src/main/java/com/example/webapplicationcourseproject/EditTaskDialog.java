package com.example.webapplicationcourseproject;

public class EditTaskDialog extends DialogFragment {
    private Task task;
    private EditText editTextTitle;
    private EditText editTextDeadline;
    private EditText editTextPriority;

    public EditTaskDialog(Task task) {
        this.task = task;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();

        View dialogView = inflater.inflate(R.layout.dialog_edit_task, null);
        editTextTitle = dialogView.findViewById(R.id.editTextTitle);
        editTextDeadline = dialogView.findViewById(R.id.editTextDeadline);
        editTextPriority = dialogView.findViewById(R.id.editTextPriority);

        // Установка текущих значений задачи в поля ввода
        editTextTitle.setText(task.getTitle());
        editTextDeadline.setText(task.getDeadline());
        editTextPriority.setText(String.valueOf(task.getPriority()));

        builder.setView(dialogView)
                .setTitle("Редактировать задачу")
                .setPositiveButton("Сохранить", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Сохраняет изменения задачи
                        String newTitle = editTextTitle.getText().toString();
                        String newDeadline = editTextDeadline.getText().toString();
                        int newPriority = Integer.parseInt(editTextPriority.getText().toString());

                        Task newTask = new Task(newTitle, newDeadline, newPriority);
                        ((TaskAdapter) recyclerViewTasks.getAdapter()).editTask(position, newTask);
                    }
                })
                .setNegativeButton("Отмена", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        // Отменяет редактирование задачи
                        dialog.dismiss();
                    }
                });

        return builder.create();
    }
}

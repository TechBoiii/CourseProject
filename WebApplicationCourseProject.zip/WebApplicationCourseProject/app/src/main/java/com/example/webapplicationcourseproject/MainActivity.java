package com.example.webapplicationcourseproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements TaskAdapter.OnItemClickListener {
    private List<Task> taskList;
    private TaskAdapter taskAdapter;
    private EditText editTextTask;

    private TaskDataManager taskDataManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskDataManager = new TaskDataManager(this);
        taskList = taskDataManager.loadTaskList();
        taskAdapter.setTaskList(taskList);
        // Настройка поля поиска
        searchView = findViewById(R.id.searchView);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                // Фильтрация списка задач на основе введенных критериев
                List<Task> filteredList = filterTasks(newText);
                ((TaskAdapter) recyclerViewTasks.getAdapter()).setTaskList(filteredList);
                return true;
            }
        });

        taskList = new ArrayList<>();
        taskAdapter = new TaskAdapter(taskList);

        RecyclerView recyclerViewTasks = findViewById(R.id.recyclerViewTasks);
        recyclerViewTasks.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewTasks.setAdapter(taskAdapter);

        editTextTask = findViewById(R.id.editTextTask);

        Button buttonAddTask = findViewById(R.id.buttonAddTask);
        buttonAddTask.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                String taskTitle = editTextTask.getText().toString();
                if (!taskTitle.isEmpty()) {
                    Task task = new Task(taskTitle);
                    taskList.add(task);
                    taskAdapter.notifyDataSetChanged();
                    editTextTask.setText("");

                }
            }
        });

        public void onItemClick(int position) {
            Task task = taskList.get(position);
            Intent intent = new Intent(this, TaskDetailActivity.class);
            intent.putExtra("task", task);
            startActivity(intent);
        }

        public boolean onItemLongClick(int position) {
            // Отмена уведомления и удаление задачи
            ((TaskAdapter) recyclerViewTasks.getAdapter()).cancelNotification(position);
            ((TaskAdapter) recyclerViewTasks.getAdapter()).removeTask(position);
            return true;
        }
        private List<Task> filterTasks(String query) {
            List<Task> filteredList = new ArrayList<>();
            for (Task task : taskList) {
                if (task.getTitle().toLowerCase().contains(query.toLowerCase())) {
                    filteredList.add(task);
                }
            }
            return filteredList;
        }
    }
    protected void onPause() {
        super.onPause();
        taskDataManager.saveTaskList(taskList);
    }
    @Override
    public void onItemClick(int position) {

    }
}

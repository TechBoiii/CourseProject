package com.example.webapplicationcourseproject;

public class SubTaskAdapter extends RecyclerView.Adapter<SubTaskAdapter.SubTaskViewHolder> {
    private List<Task> subTaskList;

    public SubTaskAdapter(List<Task> subTaskList) {
        this.subTaskList = subTaskList;
    }

    @NonNull
    public SubTaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
    }


    public void onBindViewHolder(@NonNull SubTaskViewHolder holder, int position) {
        Task subTask = subTaskList.get(position);
        holder.textViewSubTaskTitle.setText(subTask.getTitle());
        // ...
    }

    public int getItemCount() {
        return subTaskList.size();
    }

    public static class SubTaskViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewSubTaskTitle;


        public SubTaskViewHolder(@NonNull View itemView) {
            super(itemView);
            textViewSubTaskTitle = itemView.findViewById(R.id.textViewSubTaskTitle);

        }
    }
}
